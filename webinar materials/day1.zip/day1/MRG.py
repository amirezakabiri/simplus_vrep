import client
from simplus_pb2 import *
import numpy as np
import time


#   We see how to control robots for a simple objective,
#    (like moving forward and not to hit obstacles) in here.
#    Now we want so write controller for a harder objective. Solving the Maze!
#    In this practice we use and intiutive and naive approuch for solving maze, and
#    in next tutorial we see A* an optimum  algorithm for solving maze


    

info = WorldInfo()  # You can access world info everywhere



def Start(world_info, team_info):
    """ THIS FUNCTION WILL BE CALLED IN THE BEGINING
        world_info : IN  {team_count, robot_per_team, color_sensors, distance_sensors, check_points}
        team_info  : OUT {name}
    """
    global info
    info = world_info
    # Fill your team information
    team_info.name = 'MRG'


def End(server, result):
    """ THIS FUNCTION WILL BE CALLED AT THE END
        server : IN server Infomation {time, score, state}
        result : OUT {message, map}
    """
    # Get ending server info from server

    # Fill your final result here

    result.message = 'Good game!'


def move(direction,command):
        ############### move to direction ##################

    if direction == 'FORWARD':
        command.linear =  0.1
        command.angular = 0.0
    elif direction == 'BACKWARD':
        command.linear = -0.1 # Set a negative value to make robot go backward (See. Forward)
        command.angular = 0.0 # Set the 0 value to make robot go backward (See. Forward)
    elif direction == 'TURN_LEFT':
        command.linear = 0.0
        command.angular = 0.8
    elif direction == 'TURN_RIGHT':
        command.linear = 0.0 # Set the 0 value to make robot turn right (See. Turn Left)
        command.angular = -0.8  # Set a negative value to make robot turn right (See. Turn Left)
    elif direction == 'STOP':
        command.linear = 0.0
        command.angular = 0.0

PRE_MOVE = 'FORWARD';
DURATION = 0;
CHECK_CYLE = 0

def Play(id, server, observation, command):
    """ THIS FUNCTION WILL BE CALLED FOR EACH ROBOT
        id         : IN robot ID
        server     : IN server Infomation {time, score, state}
        observation: IN {camera, position, color[], distance[]}
        command    : OUT {linear, angular, LED, actions[]}
    """

    global PRE_MOVE
    global DURATION
    global CHECK_CYLE

    #move strategy   
    #
    #    Map of Sensor location on Robot
    #
    #           /--- *2* ---- *3* ---\
    #          /                      \
    #        *1*                      *4*
    #         |       SIMPLUS          |
    #        *0*        ROBOT         *5*
    #         |                        |
    #          \                      /
    #          *7* -----------------*6*
    # 

    ############### check proximity sensor's status ################

    direction='FORWARD'

    if DURATION == 0:
        obstacles = [False,False,False,False,False,False,False,False]

        sensivity = 5  # Higher number means robot more afraid of hitting obstacles
        min_dist= 1/sensivity
        for i in range(0,8):
           if (observation.distances[i].detected and observation.distances[i].distance<min_dist):
                 obstacles[i] = True
        
        ############# Decide ###################
        sensors = [False,False,False]
        i = 0
        for c in observation.colors:
            if(c.r>100 and c.r<215 and c.g<215 and c.b<215 and abs(int(c.r)-int(c.g))<45 and abs(int(c.g)-int(c.b))<45 and  abs(int(c.r)-int(c.b))<45 ): 
                  sensors[i]  = True
            i = i+1

        if server.time - CHECK_CYLE > 20:
            if sensors[0] and sensors[1] and sensors[2]:
                direction='FORWARD'
                CHECK_CYLE  = server.time
                move(direction,command)
                return
            elif sensors[2] : #left
                direction='TURN_LEFT'
                move(direction,command)
                return
            elif sensors[1] : #right
                direction='TURN_RIGHT'
                move(direction,command)
                return


        if not obstacles[2] and not obstacles[3] and not obstacles[0] and not obstacles[1] and not obstacles[4] and not obstacles[5]: 
            if server.time %15  < 10: #random
                    direction='FORWARD'
            else:
                    direction='TURN_RIGHT'
            DURATION = 1
        elif not obstacles[2] and not obstacles[3]: #front is block
                DURATION = 1
                direction='FORWARD'
        elif not obstacles[0] and not obstacles[1] and not obstacles[4] and not obstacles[5]:
            if server.time %10  < 4: #random
                    direction='TURN_LEFT'
            else:
                    direction='TURN_RIGHT'
            DURATION = 1
        elif not obstacles[0] and not obstacles[1] : #can turn left
            DURATION = 1
            direction='TURN_LEFT'

        elif not obstacles[4] and not obstacles[5] : #can turn right
            DURATION = 1
            direction='TURN_RIGHT'

        else: #turn back
            DURATION = 4
            direction='TURN_LEFT'
      
        PRE_MOVE = direction
    else:
        direction = PRE_MOVE
    
    DURATION = DURATION - 1
    move(direction,command)
    print(direction) 



  
    