#include <iostream>
#include <memory>
#include <string>
#include <stdlib.h>     /* abs */
#include<time.h> 

using namespace std;


int team_size,robot_per_team,color_sensor_size,proximity_sensor_size,server_time;

extern "C" {


 char *  start(int _team_size,int _robot_per_team,int _color_sensor_size,int _proximity_sensor_size){
  team_size=_team_size;
  robot_per_team=_robot_per_team;
  color_sensor_size=_color_sensor_size;
  proximity_sensor_size=_proximity_sensor_size;
  server_time=0;
  return "Zenith";
}


char * end(){
  return  "The Ending Message";

  
}


char last_turn='F';

 char* play(int colors_1[],int colors_2[],int colors_3[],int proximity_detected[],float proximity_distances[],float pos[],int image_r[],int image_g[],int image_b[],int thermal[],int *led_color_id,float *wheel_linear, float *wheel_angular,float * action_x,float * action_y,float * action_z){

    *led_color_id = 2; //green


   //move strategy   
    //
    //    Map of Sensor location on Robot
    //
    //           /--- *2* ---- *3* ---\
    //          /                      \
    //        *1*                      *4*
    //         |       SIMPLUS          |
    //        *0*        ROBOT         *5*
    //         |                        |
    //          \                      /
    //          *7* -----------------*6*
    // 

    ////////////////////////////// check proximity sensor's status ////////////////////////////////

    int is_obstacle_Front = 0;
    int is_obstacle_Left = 0;
    int is_obstacle_Right = 0;


    float min_dist = 0.2; //smaller number means robot more afraid of hitting obstacles
    if( (proximity_detected[2] == 1 &&  proximity_distances[2] < min_dist) || (proximity_detected[3] == 1 &&  proximity_distances[3] < min_dist))
       is_obstacle_Front = 1;

    if( (proximity_detected[0] == 1 &&  proximity_distances[0] < min_dist) || (proximity_detected[1] == 1 &&  proximity_distances[1] < min_dist))
       is_obstacle_Left = 1;

    if( (proximity_detected[4] == 1 &&  proximity_distances[4] < min_dist) || (proximity_detected[5] == 1 &&  proximity_distances[5] < min_dist))
       is_obstacle_Right = 1;

   ///////////// Decide ///////////////

    char direction = 'F';

    if ( is_obstacle_Front  == 0)
    {
        direction = 'F';
    }
    else if (last_turn == 'F'){

        if( is_obstacle_Left == 0 && is_obstacle_Right == 0 ){

          srand(time(0)); 
          if (rand()%2 ==0)
            direction = 'R';
          else
            direction = 'L';
        }
        else if(is_obstacle_Right == 0 && last_turn!='L')
              direction = 'R';
        else if(is_obstacle_Left == 0 && last_turn!='R' )
              direction = 'L';
        else 
              direction = 'D'; //drift


    }
    else{
      direction = last_turn;
    }
    
    last_turn = direction;    

 
    ///////////////// move //////////////
    if (direction == 'F'){
        *wheel_linear =  0.17;
        *wheel_angular  = 0.0;
      }
    else if (direction == 'B'){
        *wheel_linear = -0.1; 
        *wheel_angular  = 0.0;
      }
    else if (direction == 'L'){
        *wheel_linear = 0.0;
        *wheel_angular  = 0.9;
       }
    else if (direction == 'R'){
        *wheel_linear = 0.0; 
        *wheel_angular  = -0.5;  
      }
    else if (direction == 'S'){
        *wheel_linear = 0.0;
        *wheel_angular  = 0.0;
      }
    else if (direction == 'D'){
        *wheel_linear = 0.0;
        *wheel_angular  = -2;
      }
  

  return "";

}

}
