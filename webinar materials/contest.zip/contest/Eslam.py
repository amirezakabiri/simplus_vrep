import client
from simplus_pb2 import *
import numpy as np
import time
import cv2

victims_Visited=[]

info = WorldInfo()  # You can access world info everywhere

# Convert raw image to open cv image
def convert_to_cv_img(img_raw, h, w):
    img_array = np.frombuffer(img_raw, dtype=np.uint8)
    img = img_array.reshape(h, w, 3)
    img_center = (w / 2, h / 2)
    mirrored_img = cv2.getRotationMatrix2D(img_center, 180.0, 1.0)
    main_img = cv2.warpAffine(img, mirrored_img, (w, h))
    main_img = cv2.flip(main_img, 1)
    return main_img

def find_victim(img):

    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

    contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        x,y,w,h = cv2.boundingRect(cnt)
    i=0
    victims=[]
    img_h,img_w = img.shape
    for cnt in contours:
        x,y,w,h = cv2.boundingRect(cnt)
        if (img_w - w)<20 or (img_h - h)<20 or w>90 or h>90:
            continue
        if w<22 or h<22:
            continue
            #save individual images
        victims.append((x,y,h,w))
        print((x,y,h,w))
        i=i+1

    return victims


def Start(world_info, team_info):
    """ THIS FUNCTION WILL BE CALLED IN THE BEGINING
        world_info : IN  {team_count, robot_per_team, color_sensors, distance_sensors, check_points}
        team_info  : OUT {name}
    """
    global info
    info = world_info
    # Fill your team information
    team_info.name = 'Eslam'


def End(server, result):
    """ THIS FUNCTION WILL BE CALLED AT THE END
        server : IN server Infomation {time, score, state}
        result : OUT {message, map}
    """
    # Get ending server info from server

    # Fill your final result here

    result.message = 'Good game!'




PRE_MOVE='FORWARD';

def Play(id, server, observation, command):
    """ THIS FUNCTION WILL BE CALLED FOR EACH ROBOT
        id         : IN robot ID
        server     : IN server Infomation {time, score, state}
        observation: IN {camera, position, color[], distance[]}
        command    : OUT {linear, angular, LED, actions[]}
    """ 

    global PRE_MOVE
    

    is_obstacle_left = False
    is_obstacle_right = False
    is_obstacle_Front = False

    is_black_left = False    
    is_black_right = False
    is_black_Front = False

    #front
    if (observation.distances[3].detected and observation.distances[3].distance<0.15) or (observation.distances[2].detected and observation.distances[2].distance<0.16):
         is_obstacle_Front=True

    sum_color = (observation.colors[0].r + observation.colors[0].g + observation.colors[0].b) 
    if ( sum_color >5 and sum_color<30):
        is_black_Front= True  

    #left
    if (observation.distances[1].detected and observation.distances[1].distance<0.15) or (observation.distances[0].detected and observation.distances[0].distance<0.16) :
        is_obstacle_left =True

    sum_color= (observation.colors[1].r + observation.colors[1].g + observation.colors[1].b) 
    if ( sum_color >5 and sum_color<30):
            is_black_left = True  

    #right 
    if (observation.distances[4].detected and observation.distances[4].distance<0.15) or (observation.distances[5].detected and observation.distances[5].distance<0.16) :
        is_obstacle_right =True

    sum_color= (observation.colors[2].r + observation.colors[2].g + observation.colors[2].b) 
    if ( sum_color >5 and sum_color<30):
            is_black_right = True  

    ############# Decide ###################
    if (server.time < 18) and not is_black_Front:
        direction = 'FORWARD'
    elif(server.time < 23 and not is_black_left):
        direction = 'TURN_LEFT' 
    elif not is_obstacle_Front and not is_black_Front :
        direction='FORWARD'
    elif not is_obstacle_left  and not is_black_left:  
        direction='TURN_LEFT'
    elif not is_obstacle_right and not is_black_right :   
        direction='TURN_RIGHT'
    elif  (is_obstacle_left or is_black_left) and  (is_obstacle_Front or is_black_Front) and  (is_obstacle_right or is_black_right):
        direction='BACKWARD'
    elif server.time %10  > 7: # 3 step
        direction='TURN_LEFT'
    else: # forward
        direction='FORWARD'

    PRE_MOVE = direction

    ############### move to direction ##################

    if direction == 'FORWARD':
        command.linear =  0.17
        command.angular = 0.0
    if direction == 'BACKWARD':
        command.linear = -0.1 # Set a negative value to make robot go backward (See. Forward)
        command.angular = -1 # Set the 0 value to make robot go backward (See. Forward)
    if direction == 'TURN_LEFT':
        command.linear = 0.0
        command.angular = 0.6
    if direction == 'TURN_RIGHT':
        command.linear = 0.0 # Set the 0 value to make robot turn right (See. Turn Left)
        command.angular = -0.7 # Set a negative value to make robot turn right (See. Turn Left)
    if direction == 'STOP':
        command.linear = 0.0
        command.angular = 0.0
  
    global victims_Visited
    for victim in  victims_Visited:
        x,y,z = victim
        tmp= pow(observation.pos.x - x, 2) + pow(observation.pos.y - y, 2) + pow(
                observation.pos.z - z, 2)
        distance= pow(tmp, 0.5)
        if distance < 0.25:
           return
    img = convert_to_cv_img(observation.camera.raw, observation.camera.h, observation.camera.w)
    victims =find_victim(img)
    if len(victims) >0 and is_obstacle_Front:
        command.actions.append(Action(x=observation.pos.x,y=observation.pos.y,z=observation.pos.z,type='find_victim')) 
        victims_Visited.append((observation.pos.x,observation.pos.y,observation.pos.z))


    