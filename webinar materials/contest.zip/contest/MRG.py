import client
from simplus_pb2 import *
import numpy as np
import time
import cv2 

#   We see how to control robots for a simple objective,
#    (like moving forward and not to hit obstacles) in here.
#    Now we want so write controller for a harder objective. Solving the Maze!
#    In this practice we use and intiutive and naive approuch for solving maze, and
#    in next tutorial we see A* an optimum  algorithm for solving maze


    

info = WorldInfo()  # You can access world info everywhere




def already_visited(observation):
    global victims_Visited
    for victim in  victims_Visited:
        x,y,z = victim
        tmp= pow(observation.pos.x - x, 2) + pow(observation.pos.y - y, 2) + pow(
                observation.pos.z - z, 2)
        distance= pow(tmp, 0.5)
        if distance < 0.25:
           return True;
    return False

def find_victim(img):

    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

    contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        x,y,w,h = cv2.boundingRect(cnt)
        #bound the images
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),3)
    i=0
    victims=[]
    img_h,img_w = img.shape
    for cnt in contours:
        x,y,w,h = cv2.boundingRect(cnt)
        #following if statement is to ignore the noises and save the images which are of normal size(character)
        #In order to write more general code, than specifying the dimensions as 100,
        # number of characters should be divided by word dimension
        if (img_w - w)<20 or (img_h - h)<20:
            continue
        if w<20 or h<20:
            continue
            #save individual images
        victims.append((x,y,h,w))
        print((x,y,h,w))
        i=i+1

 #   print(len(victims))
    return victims

def Start(world_info, team_info):
    """ THIS FUNCTION WILL BE CALLED IN THE BEGINING
        world_info : IN  {team_count, robot_per_team, color_sensors, distance_sensors, check_points}
        team_info  : OUT {name}
    """
    global info
    info = world_info
    # Fill your team information
    team_info.name = 'MRG'


def End(server, result):
    """ THIS FUNCTION WILL BE CALLED AT THE END
        server : IN server Infomation {time, score, state}
        result : OUT {message, map}
    """
    # Get ending server info from server

    # Fill your final result here

    result.message = 'Good game!'



startTime= int(time.time() % 60)

def  is_robot_finished(observation,server):
     # TODO 
     #implement your own finish condition algorithm
    red_tile = False
    for c in observation.colors:
        if c.r > 190 and c.g<20 and c.b < 20: #red
            red_tile=True
    if not red_tile:
        return False
    global startTime
    now = int(time.time() % 60)  
    if now-startTime>7*60:   #after 60 seconds = 7 minute 
        return True
    return False


# Convert raw image to open cv image
def convert_to_cv_img(img_raw, h, w):
    img_array = np.frombuffer(img_raw, dtype=np.uint8)
    img = img_array.reshape(h, w, 3)
    img_center = (w / 2, h / 2)
    mirrored_img = cv2.getRotationMatrix2D(img_center, 180.0, 1.0)
    main_img = cv2.warpAffine(img, mirrored_img, (w, h))
    main_img = cv2.flip(main_img, 1)
    return main_img


def find_victim(img):

    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

    contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        x,y,w,h = cv2.boundingRect(cnt)
        #bound the images
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),3)
    i=0
    victims=[]
    img_h,img_w = img.shape
    for cnt in contours:
        x,y,w,h = cv2.boundingRect(cnt)
        #improve the conditions
        if (img_w - w)<20 or (img_h - h)<20:
            continue
        if w<20 or h<20:
            continue
            #save individual images
        victims.append((x,y,h,w))
        i=i+1

    return victims


def is_victim_found(observation):

    img = convert_to_cv_img(observation.camera.raw, observation.camera.h, observation.camera.w)
    victims = find_victim(img)
    # TODO
    # double check the patches
    if len(victims)> 0:
      x,y,h,w = victims[0]
      #print("find_victim",len(victims))
      return True
    return False


def move(direction,command):
        ############### move to direction ##################
   # print(direction)
    if direction == 'FORWARD':
        command.linear =  0.17
        command.angular = 0.0
    elif direction == 'BACKWARD':
        command.linear = -0.1 # Set a negative value to make robot go backward (See. Forward)
        command.angular = 0.0 # Set the 0 value to make robot go backward (See. Forward)
    elif direction == 'TURN_LEFT':
        command.linear = 0.001
        command.angular = 0.65
    elif direction == 'TURN_RIGHT':
        command.linear = -0.03 # Set the 0 value to make robot turn right (See. Turn Left)
        command.angular = -0.8  # Set a negative value to make robot turn right (See. Turn Left)
    elif direction == 'STOP':
        command.linear = 0.0
        command.angular = 0.0

PRE_MOVE = 'FORWARD';
DURATION = 0;
CHECK_CYLE = 0
victims_Visited=[]

def Play(id, server, observation, command):
    """ THIS FUNCTION WILL BE CALLED FOR EACH ROBOT
        id         : IN robot ID
        server     : IN server Infomation {time, score, state}
        observation: IN {camera, position, color[], distance[]}
        command    : OUT {linear, angular, LED, actions[]}
    """

    global victims_Visited
   # print(server.time)

    obstacles = [False,False,False,False,False,False,False,False]

    sensivity = 5  # Higher number means robot more afraid of hitting obstacles
    min_dist= 1/sensivity
    for i in range(0,8):
        if (observation.distances[i].detected and observation.distances[i].distance<min_dist):
            obstacles[i] = True

    if  is_robot_finished(observation,server):
       command.actions.append(Action(x=observation.pos.x,y=observation.pos.y,z=observation.pos.z,type='exit')) # type -> exit

    if obstacles[2] and obstacles[3] and not already_visited(observation) and is_victim_found(observation) :
       victims_Visited.append((observation.pos.x,observation.pos.y,observation.pos.z))
       # for recieving the victim score
       command.actions.append(Action(x=observation.pos.x,y=observation.pos.y,z=observation.pos.z,type='find_victim')) 



    global PRE_MOVE
    global DURATION
    global CHECK_CYLE

    #move strategy   
    #
    #    Map of Sensor location on Robot
    #
    #           /--- *2* ---- *3* ---\
    #          /                      \
    #        *1*                      *4*
    #         |       SIMPLUS          |
    #        *0*        ROBOT         *5*
    #         |                        |
    #          \                      /
    #          *7* -----------------*6*
    # 

    ############### check proximity sensor's status ################

    direction='FORWARD'

    if DURATION <= 0:
        
        ############# Decide ###################
        sensors = [False,False,False]
        holes = [False,False,False]

        i = 0
        for c in observation.colors:
            if (c.r>100 and c.r<215 and c.g<215 and c.b<215 and abs(int(c.r)-int(c.g))<45 and abs(int(c.g)-int(c.b))<45 and  abs(int(c.r)-int(c.b))<45 ): 
                  sensors[i]  = True

            sum_color = c.r + c.b + c.g 
            if  sum_color >5 and sum_color<30 :
                  holes[i] = True

            i = i+1

        if server.time - CHECK_CYLE > 20:
            if sensors[0] and sensors[1] and sensors[2]:
                direction='FORWARD'
                CHECK_CYLE  = server.time
                move(direction,command)
                return
            elif sensors[1] :
                direction='TURN_LEFT'
                move(direction,command)
                return
            elif sensors[2] : 
                direction='TURN_RIGHT'
                move(direction,command)
                return


        if not obstacles[2] and not obstacles[3] and not obstacles[0] and not obstacles[1] and not obstacles[4] and not obstacles[5] and not holes[0] and not holes[1] and not holes[2]: 
            if server.time %15  < 10: #random
                    direction='FORWARD'
            else:
                    direction='TURN_RIGHT'
            DURATION = 1
        elif not obstacles[2] and not obstacles[3] and not holes[0]: #front is block
                DURATION = 1
                direction='FORWARD'
        elif not obstacles[0] and not obstacles[1] and not obstacles[4] and not obstacles[5] and not holes[1] and not holes[2]:
            if server.time %10  < 4: #random
                    direction='TURN_LEFT'
            else:
                    direction='TURN_RIGHT'
            DURATION = 1
        elif not obstacles[0] and not obstacles[1] and not holes[1] : #can turn left
            DURATION = 1
            direction='TURN_LEFT'

        elif not obstacles[4] and not obstacles[5] and not holes[2]: #can turn right
            DURATION = 1
            direction='TURN_RIGHT'

        else: #turn back
            DURATION = 4
            direction='TURN_LEFT'
      
        PRE_MOVE = direction
    else:
        direction = PRE_MOVE
    
    DURATION = DURATION - 1
    move(direction,command)
    # print(direction) 



  
    