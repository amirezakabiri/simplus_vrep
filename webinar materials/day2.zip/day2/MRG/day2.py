import cv2
import numpy
import matplotlib.pyplot as plt
import matplotlib.patches as patches



def find_victim(img):

	img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

	ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

	contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
	i=0
	victims=[]
	img_h,img_w = img.shape
	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		if (img_w - w)<20 or (img_h - h)<20 or w>90 or h>90:
			continue
		if w<22 or h<22:
			continue
			#save individual images
		victims.append((x,y,h,w))
		print((x,y,h,w))
		i=i+1

	print(len(victims))
	return victims


title=""
img = cv2.imread('input/victim1.png')  
victims =find_victim(img)
if len(victims) >0:
    title="found"
    x,y,h,w = victims[0]
    img = cv2.rectangle(img, (x,y), (x+w,y+h), color=(255, 0, 0), thickness=4) 
else:
    title="not found"

plt.subplot(111), plt.imshow(img, cmap='gray'), plt.title(title)  # Plot the Image
plt.show()  # Show the plotter window (You should see the image in a new window now)
