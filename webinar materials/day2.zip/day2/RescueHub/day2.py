import cv2
import numpy
import matplotlib.pyplot as plt





def find_victim(img):

	img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

	ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

	contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		#bound the images
		cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),3)
	i=0
	victims=[]
	img_h,img_w = img.shape
	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		#following if statement is to ignore the noises and save the images which are of normal size(character)
		#In order to write more general code, than specifying the dimensions as 100,
		# number of characters should be divided by word dimension
		if (img_w - w)<20 or (img_h - h)<20:
			continue
		if w<20 or h<20:
			continue
			#save individual images
		victims.append((x,y,h,w))
		print((x,y,h,w))
		i=i+1

	print(len(victims))
	return victims


img = cv2.imread('images/victim1.png')  # Read image file
print("Vision image size: ", img.shape) #(860, 1321, 3)


victims = find_victim(img)

if len(victims)> 0:
  x,y,h,w = victims[0]

  img = cv2.rectangle(img, (x,y), (x+w,y+h), color=(0, 0, 255), thickness=3) 

else:
   print("No victim found!")

plt.subplot(111), plt.imshow(img, cmap='gray'), plt.title('Victim')  # Plot the Image
plt.show()  # Show the plotter window (You should see the image in a new window now)
