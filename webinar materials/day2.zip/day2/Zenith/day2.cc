
#include <string>
#include <iostream>
#include "opencv2/opencv.hpp"



using namespace std;
using namespace cv;



Rect victim;





int main(int argc, char* argv[])
{

    Mat image;
    image = imread("day2_challange/victim6.png", IMREAD_UNCHANGED);   // Read the file
        if(! image.data )                              // Check for invalid input
    {
        cout <<  "Could not open or find the image" << std::endl ;
        return -1;
    }
   int check=0;

   Mat tmp,tmp2;
   cvtColor( image, tmp, COLOR_BGR2GRAY );
   threshold( tmp, tmp2, 127, 255,0 );  //binary
   vector<vector<Point> > contours;
   vector<Vec4i> hierarchy;
   findContours( tmp2, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE, Point(0, 0) );

  vector<vector<Point> > contours_poly( contours.size() );
  vector<Rect> boundRect( contours.size() );
  for( int i = 0; i < contours.size(); i++ )
     { approxPolyDP( Mat(contours[i]), contours_poly[i], 3, true );
       boundRect[i] = boundingRect( Mat(contours_poly[i]) );
       int w = boundRect[i].width ;
       int h = boundRect[i].height;
       if (w<20 || h<20 || w>200 || h>200)
          continue;
       if(image.size().width-w <10 || image.size().height-h <20)
          continue; 
       victim = boundRect[i];
       check=1;
       break;
     }
  
  if(check == 1){
	  /// Draw rectangle around letter
	  RNG rng(12345);
	  Scalar color = Scalar( rng.uniform(0, 255), rng.uniform(0,255), rng.uniform(0,255) );
	  rectangle( image, victim.tl(), victim.br(), color, 2, 8, 0 );
	}
   else{
   	  cout << "Victim not found";
   }
  // /// Show in a window
  namedWindow( "victim", WINDOW_AUTOSIZE );
  imshow( "victim", image );




    waitKey(0);                                          // Wait for a keystroke in the window
    return 0;
}



