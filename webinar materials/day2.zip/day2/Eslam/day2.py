import cv2
import numpy
import matplotlib.pyplot as plt

def find_victim_big(img):

	img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

	ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

	contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),3)
	i=0
	victims=[]
	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		if w>100 and w<130 and h>100 and h<130:
			victims.append((x,y,h,w))
			i=i+1

	return victims

def find_victim(img):

	img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

	ret,thresh1 = cv2.threshold(img,127,255,cv2.THRESH_BINARY)

	contours, hierarchy = cv2.findContours(thresh1,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),3)
	i=0
	victims=[]
	img_h,img_w = img.shape
	for cnt in contours:
		x,y,w,h = cv2.boundingRect(cnt)
		if (img_w - w)<20 or (img_h - h)<20:
			continue
		if w<20 or h<20:
			continue
		victims.append((x,y,h,w))
		print((x,y,h,w))
		i=i+1

	print('number of victims: ',len(victims))
		
	return victims

img = cv2.imread('img/vision.png')  

if (img.shape > (150,150,3)):
	victims = find_victim_big(img)
	
	if len(victims)> 0:
	  x,y,h,w = victims[0]
	  img = cv2.rectangle(img, (x,y), (x+w,y+h), color=(255, 0, 0), thickness=10) 
	
	else:
   		print("No victim found!")
	
	plt.subplot(111), plt.imshow(img, cmap='gray'), plt.title(img.shape)  
	print('large')

elif (img.shape < (150,150,3)):
	svictim = find_victim(img)
	if len(svictim)> 0:
 		x,y,h,w = svictim[0]
	 	img = cv2.rectangle(img, (x,y), (x+w,y+h), color=(0, 255, 0), thickness=4) 
	else:
   		print("No victim found!")
	plt.subplot(111), plt.imshow(img, cmap='gray'), plt.title(img.shape)  # Plot the Image
	print('small')

plt.show()

